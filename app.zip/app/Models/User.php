<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory;
    use Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    /**
     *  =============== RELATIONSHIPS  ===============.
     */
    public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class, 'cart', 'user_id', 'product_id')
                    ->withPivot('id', 'quantity')
                    ->withTimestamps();
    }

    public function pet(): HasOne
    {
        return $this->hasOne(Pet::class);
    }

    // Points/Games
    public function pointsWallet()
    {
        return $this->hasOne(PointsWallet::class);
    }

    public function quizAnswers()
    {
        return $this->hasMany(UserQuizAnswer::class);
    }

    public function gameScores()
    {
        return $this->hasMany(UserGameScore::class);
    }

    /**
     *  =============== SCOPES  ===============.
     */

    /**
     *  =============== FUNCTIONS  ===============.
     */
    public function getGroups(): array
    {
        $group_ids = [1];

        return $group_ids;
    }

    // ----------------------------
    // Points Helper Functions
    // ----------------------------

    /**
     * Get current points balance.
     */
    public function getPoints(): int
    {
        return $this->pointsWallet ? $this->pointsWallet->points_balance : 0;
    }

    /**
     * Add points to the wallet.
     */
    public function addPoints(int $points, string $description = 'Earned points'): void
    {
        $wallet = $this->pointsWallet;

        if (!$wallet) {
            $wallet = PointsWallet::create([
                'user_id' => $this->id,
                'points_balance' => 0,
            ]);
        }

        $wallet->points_balance += $points;
        $wallet->save();

        PointsTransaction::create([
            'user_id' => $this->id,
            'points' => $points,
            'type' => 'earn',
            'description' => $description,
        ]);
    }

    /**
     * Deduct points from wallet.
     */
    public function deductPoints(int $points, string $description = 'Redeemed points'): bool
    {
        $wallet = $this->pointsWallet;

        if (!$wallet || $wallet->points_balance < $points) {
            return false; // Not enough points
        }

        $wallet->points_balance -= $points;
        $wallet->save();

        PointsTransaction::create([
            'user_id' => $this->id,
            'points' => -$points,
            'type' => 'redeem',
            'description' => $description,
        ]);

        return true;
    }

    // ----------------------------
    // Booted Event
    // ----------------------------

    /**
     * Automatically create wallet on user registration.
     */
    protected static function booted()
    {
        static::created(function ($user) {
            PointsWallet::create([
                'user_id' => $user->id,
                'points_balance' => 0,
            ]);
        });
    }
}
